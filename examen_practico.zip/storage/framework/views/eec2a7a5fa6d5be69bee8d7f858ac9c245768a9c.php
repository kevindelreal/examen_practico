

<?php $__env->startSection('title', "Prospectos"); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header text-white bg-primary">
                <div class="d-inline p-2 bg-primary text-white" style="font-size: 20px;">
                    Prospectos
                </div>
                
                <a href="<?php echo e(route('prospecto.create')); ?>"
                class="btn btn-sm btn-success float-right">
                Nuevo Prospecto
                </a>
            </div>

            <div class="card-body">
                <table id="myTable" class="table table-responsive-sm">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Primer Apellido</th>
                            <th>Segundo Apellido</th>
                            <th class="text-center">Estatus</th>
                            <th class="text-center">Acción</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap4.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            var table = $('#myTable').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('prospecto.prospectos_datatable')); ?>",
                columns: [
                    {data: 'id', name: 'id'},
                    {data: 'nombre', name: 'nombre'},
                    {data: 'primer_apellido', name: 'primer_apellido'},
                    {data: 'segundo_apellido', name: 'segundo_apellido'},
                    {data: 'estatus_nombre', name: 'estatus_nombre', sClass: "text-center"},
                    {
                        data: 'action', 
                        name: 'action', 
                        orderable: false, 
                        searchable: false,
                        sClass: "text-center"
                    },
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\examen_practico\resources\views/prospectos/index.blade.php ENDPATH**/ ?>