<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Examen Practico</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/datatables.bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.css')); ?>">
    
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
    <div id="app">
        <main class="py-4">
            <?php if(session('info')): ?>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-8 col-md-offset-2">
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                
                                <?php echo e(session('info')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    
    <div class="col-lg-12" style="padding-top:-70px;">
        <?php echo $__env->yieldContent('index'); ?>
    </div>

    <!-- All that javascript -->
    <script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sweetalert2.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\examen_practico\resources\views/layouts/app.blade.php ENDPATH**/ ?>