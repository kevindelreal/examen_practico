

<?php $__env->startSection('title', "Información del prospectos"); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header text-white bg-dark">
                    <h5 class="mb-0">Información del prospectos</h5> 
                </div>

                <div class="card-body">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('POST')); ?>

            
                    <div class="row">
                        <div class="col-md-4">
                            <!-- Nombre -->
                            <div class="form-group">
                                <dt for="name">Nombre:</dt>
                                <dd><?php echo e($prospecto->nombre); ?></dd>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <!-- Primer Apellido -->
                            <div class="form-group">
                                <dt for="name">Primer Apellido:</dt>
                                <dd><?php echo e($prospecto->primer_apellido); ?></dd>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <!-- Segundo Apellido -->
                            <div class="form-group">
                                <dt for="name">Segundo Apellido:</dt>
                                <dd><?php echo e($prospecto->segundo_apellido); ?></dd>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <!-- Calle -->
                            <div class="form-group">
                                <dt for="name">Calle:</dt>
                                <dd><?php echo e($prospecto->calle); ?></dd>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <!-- Numero -->
                            <div class="form-group">
                                <dt for="name">Numero:</dt>
                                <dd><?php echo e($prospecto->numero); ?></dd>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <!-- Colonia -->
                            <div class="form-group">
                                <dt for="name">Colonia:</dt>
                                <dd><?php echo e($prospecto->colonia); ?></dd>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <!-- Codigo Postal -->
                            <div class="form-group">
                                <dt for="name">Codigo Postal:</dt>
                                <dd><?php echo e($prospecto->codigo_postal); ?></dd>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <!-- Telefono -->
                            <div class="form-group">
                                <dt for="name">Telefono:</dt>
                                <dd><?php echo e($prospecto->telefono); ?></dd>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <!-- RFC -->
                            <div class="form-group">
                                <dt for="name">RFC:</dt>
                                <dd><?php echo e($prospecto->rfc); ?></dd>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <dt for="name">Estatus:</dt>
                                <dd><?php echo e($prospecto->estatus->nombre); ?></dd>
                            </div>
                        </div>

                        <?php if($prospecto->estatus->id == 3): ?>
                            <div class="col-md-4" id="observaciones">
                                <dt for="name">Observaciones:</dt>
                                
                                <dd><?php echo e($prospecto->observaciones); ?></dd>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <?php $__currentLoopData = $archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="btn btn-primary" target="_blank" href="<?php echo e($value->url_path); ?>">
                                    <?php echo e($value->nombre); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-2">
                <div class="col-md-12">
                    <a href="<?php echo e(route('prospecto.index')); ?>"
                        class="btn btn-primary btn-block mt-2">
                        Volver
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\examen_practico\resources\views/prospectos/show.blade.php ENDPATH**/ ?>